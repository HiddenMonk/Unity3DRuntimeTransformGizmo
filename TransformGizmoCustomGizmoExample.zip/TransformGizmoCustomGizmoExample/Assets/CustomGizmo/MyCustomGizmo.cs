﻿using System;
using UnityEngine;
using RuntimeGizmos;

public class MyCustomGizmo : TransformGizmoCustomGizmo
{

}